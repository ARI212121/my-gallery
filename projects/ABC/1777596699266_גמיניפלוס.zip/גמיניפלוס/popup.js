// === חובה: הדבק כאן את כתובת הגוגל סקריפט שלך (Code.gs) ===
const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzwBEcoiTPUOckY6lQKxn5JGMQ4Zq68AXACrpIyaJ_OhWS6aTwszLWpq4_w5leecFiJQQ/exec";

let currentlyDownloading = false;

document.addEventListener('DOMContentLoaded', () => {
    loadCapturedRequests();
    loadRadarLogs();
    
    document.getElementById('toggle_radar_btn').addEventListener('click', toggleRadar);
});

function loadCapturedRequests() {
    chrome.storage.local.get(['recentDownloads'], (data) => {
        const list = document.getElementById('requests_list');
        const recent = data.recentDownloads || [];
        if (recent.length === 0) return;
        
        list.innerHTML = ''; 
        
        recent.forEach((req) => {
            const card = document.createElement('div');
            card.className = 'request-card';
            
            // תצוגת הכרטיסייה החדשה הכוללת משקל ופורמט קובץ
            card.innerHTML = `
                <div class="req-header">
                    <span>זמן: ${req.timestamp}</span>
                    <span style="color: #2563eb;">סוג: ${req.type}</span>
                </div>
                <div style="font-size: 11px; color: #475569; margin-bottom: 8px; background: #f8fafc; padding: 4px; border-radius: 4px; border: 1px solid #e2e8f0;">
                    משקל: <b>${req.size || 'לא ידוע'}</b> | פורמט: <b>${req.mimeType || 'לא ידוע'}</b>
                </div>
                <div class="req-url">${req.url}</div>
                <button class="download-btn">הורד דרך השרת העוקף</button>
            `;
            
            card.querySelector('.download-btn').addEventListener('click', () => {
                startDownload(req);
            });
            
            list.appendChild(card);
        });
    });
}

function loadRadarLogs() {
    chrome.storage.local.get(['debugLogs'], (data) => {
        const panel = document.getElementById('radar_panel');
        const logs = data.debugLogs || [];
        
        if (logs.length === 0) {
            panel.innerHTML = "<div class='empty-state'>הרדאר ריק. התוסף לא מזהה שום תעבורה לגוגל.</div>";
            return;
        }

        let html = "<div style='font-size:11px; margin-bottom:10px;'><b>מקרא:</b> ירוק = יש גישה. אדום = חסר.</div>";
        logs.forEach(log => {
            const cookieClass = log.hasCookie ? "has-cookie" : "no-cookie";
            // תצוגת הרדאר החדשה הכוללת משקל ופורמט קובץ
            html += `
                <div class="log-entry ${cookieClass}">
                    <b>[${log.time}]</b> Type: ${log.type} | Size: ${log.size || '?'} | Format: ${log.mimeType || '?'}<br>
                    ${log.url.substring(0, 80)}...
                </div>
            `;
        });
        
        html += `<button id="clear_logs_btn" style="background:#ef4444; margin-top:10px; width:100%; padding:8px; color:white; border:none; border-radius:4px; cursor:pointer;">נקה היסטוריה</button>`;
        panel.innerHTML = html;
        
        document.getElementById('clear_logs_btn').addEventListener('click', clearLogs);
    });
}

function toggleRadar() {
    const panel = document.getElementById('radar_panel');
    panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
}

function clearLogs() {
    chrome.storage.local.set({ recentDownloads: [], debugLogs: [] }, () => {
        window.location.reload();
    });
}

function showStatus(msg, isError = false) {
    const box = document.getElementById('status_box');
    box.style.display = 'block';
    box.style.background = isError ? '#fee2e2' : '#e0e7ff';
    box.style.color = isError ? '#991b1b' : '#3730a3';
    box.innerText = msg;
}

function updateProgress(percent) {
    const container = document.getElementById('progress_container');
    const bar = document.getElementById('progress_bar');
    container.style.display = 'block';
    bar.style.width = percent + '%';
}

async function startDownload(capturedData) {
    if (currentlyDownloading) return;
    currentlyDownloading = true;
    document.querySelectorAll('button').forEach(b => b.disabled = true);

    try {
        showStatus("יוצר קשר עם שרת הסקריפט...");
        updateProgress(0);

        const injectedParsedData = {
            url: capturedData.url,
            headers: capturedData.headers
        };

        const sizeRes = await fetch(SCRIPT_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: JSON.stringify({
                action: "init_gemini_download",
                rawCurl: `curl '${capturedData.url}' -H 'Cookie: ${capturedData.headers.Cookie}' -H 'User-Agent: ${capturedData.headers["User-Agent"] || ""}'`
            })
        }).then(r => r.json());

        if (sizeRes.error) throw new Error(sizeRes.error);

        const totalBytes = sizeRes.size;
        const fileName = sizeRes.fileName || "gemini_media_file";
        const CHUNK_SIZE = 49 * 1024 * 1024;
        const isSingleFile = totalBytes <= CHUNK_SIZE;
        
        let downloadedBytes = 0;
        let partIndex = 1;

        for (let start = 0; start < totalBytes; start += CHUNK_SIZE) {
            let end = Math.min(start + CHUNK_SIZE - 1, totalBytes - 1);
            let percent = Math.round((downloadedBytes / totalBytes) * 100);
            let currentFileName = isSingleFile ? fileName : `${fileName}.part${("000" + partIndex).slice(-3)}`;
            
            showStatus(`מוריד: ${currentFileName} (${percent}%)`);
            updateProgress(percent);

            const chunkRes = await fetch(SCRIPT_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify({
                    action: "download_gemini_chunk",
                    parsedData: injectedParsedData,
                    start: start,
                    end: end
                })
            }).then(r => r.json());

            if (chunkRes.error) throw new Error(chunkRes.error);
            if (chunkRes.type === 'end_of_file') break;

            const byteCharacters = atob(chunkRes.data);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            
            // במידה ויש לנו MIME מדויק שחזר מהשרת עכשיו נשתמש בו ליצירת הקובץ
            let mimeType = capturedData.mimeType !== 'ממתין לתשובה...' ? capturedData.mimeType : "application/octet-stream";
            if (capturedData.type === 'תמונה' && mimeType === "application/octet-stream") mimeType = "image/png";

            const blob = new Blob([byteArray], {type: mimeType});
            
            const link = document.createElement('a');
            const objectUrl = URL.createObjectURL(blob);
            link.href = objectUrl;
            
            let finalDownloadName = currentFileName;
            // הוספת סיומת תמונה אם חסרה
            if (capturedData.type === 'תמונה' && !finalDownloadName.includes('.')) {
                if (mimeType.includes('jpeg')) finalDownloadName += ".jpg";
                else if (mimeType.includes('webp')) finalDownloadName += ".webp";
                else finalDownloadName += ".png";
            }
            link.download = finalDownloadName;
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            setTimeout(() => { URL.revokeObjectURL(objectUrl); }, 60000);
            downloadedBytes += chunkRes.actualSize;
            partIndex++;
        }

        showStatus("ההורדה הסתיימה בהצלחה!");
        updateProgress(100);

    } catch (e) {
        showStatus("שגיאה: " + e.message, true);
        updateProgress(0);
    } finally {
        currentlyDownloading = false;
        document.querySelectorAll('button').forEach(b => b.disabled = false);
    }
}
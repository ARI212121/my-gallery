const MAX_HISTORY = 15;
const MAX_DEBUG = 30;

// --- הוספת מנגנון פעימת לב (Keep-Alive) ---
// כרום מודרני "מרדים" תוספים שרצים ברקע כדי לחסוך בסוללה אחרי 30 שניות.
// הפונקציה הזו מריצה קריאת סרק לזיכרון כל 20 שניות, ומכריחה את התוסף להישאר ער ודרוך 24/7!
setInterval(() => {
  chrome.storage.local.get('keepAlive', () => {});
}, 20000);
// ------------------------------------------

// מאזין 1: לוכד את הבקשה כשהיא יוצאת (כדי לתפוס את העוגיות והכתובת)
chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    const url = details.url;
    
    // סינון לרדאר: כל דבר שקשור לגוגל
    if (url.includes("google")) {
      
      let capturedHeaders = {};
      let hasCookie = false;
      
      if (details.requestHeaders) {
          for (let header of details.requestHeaders) {
            capturedHeaders[header.name] = header.value;
            if (header.name.toLowerCase() === 'cookie') hasCookie = true;
          }
      }

      let logEntry = {
          id: details.requestId, // מזהה ייחודי לבקשה כדי שנוכל לשדך לה נתונים אחר כך
          time: new Date().toLocaleTimeString(),
          url: url,
          type: details.type, 
          hasCookie: hasCookie,
          size: 'מחשב...', // ערך זמני
          mimeType: 'ממתין לתשובה...' // ערך זמני
      };

      chrome.storage.local.get(['recentDownloads', 'debugLogs'], (data) => {
        let logs = data.debugLogs || [];
        
        // מניעת הצפה
        if (logs.length > 0 && logs[0].url === url) return;

        logs.unshift(logEntry);
        logs = logs.slice(0, MAX_DEBUG);
        chrome.storage.local.set({ debugLogs: logs });

        // === לוגיקת זיהוי ההורדות עצמן ===
        const isMedia = details.type === 'media' || details.type === 'xmlhttprequest' || details.type === 'image';
        const isTargetServer = url.includes("usercontent") || url.includes("download") || url.includes("generativelanguage");
        const isProfilePic = url.includes("photo.jpg") || url.includes("s32-c");

        if (isMedia && isTargetServer && !isProfilePic) {
            let recent = data.recentDownloads || [];
            
            if (recent.length > 0 && recent[0].url === url) return;
            
            let reqData = {
                id: details.requestId, // מזהה ייחודי
                url: url,
                headers: capturedHeaders,
                timestamp: logEntry.time,
                type: details.type === 'image' ? 'תמונה' : (url.includes('download') ? 'הורדה' : 'מדיה'),
                size: 'מחשב...',
                mimeType: 'ממתין לתשובה...'
            };
            
            recent.unshift(reqData);
            recent = recent.slice(0, MAX_HISTORY);
            chrome.storage.local.set({ recentDownloads: recent });
        }
      });
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders", "extraHeaders"]
);

// מאזין 2: לוכד את התשובה שחוזרת מהשרת (כדי לדלות משקל וסוג קובץ מדויק)
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const url = details.url;
    if (!url.includes("google")) return; // חיסכון במשאבים, עובדים רק על גוגל

    let contentLength = null;
    let contentType = null;

    // שליפת המשקל וסוג הקובץ מתוך כותרות התשובה של השרת
    if (details.responseHeaders) {
        for (let header of details.responseHeaders) {
            if (header.name.toLowerCase() === 'content-length') contentLength = header.value;
            if (header.name.toLowerCase() === 'content-type') contentType = header.value;
        }
    }

    // אם קיבלנו מידע חדש, נעדכן את הזיכרון לפי המזהה הייחודי של הבקשה (requestId)
    if (contentLength || contentType) {
        chrome.storage.local.get(['recentDownloads', 'debugLogs'], (data) => {
            let recent = data.recentDownloads || [];
            let logs = data.debugLogs || [];
            let updated = false;

            // עדכון רשימת ההורדות הראשית
            for (let i = 0; i < recent.length; i++) {
                if (recent[i].id === details.requestId) {
                    if (contentLength) {
                        let bytes = parseInt(contentLength);
                        if (bytes > 1024 * 1024) recent[i].size = (bytes / (1024 * 1024)).toFixed(2) + ' MB';
                        else if (bytes > 1024) recent[i].size = (bytes / 1024).toFixed(2) + ' KB';
                        else recent[i].size = bytes + ' Bytes';
                    }
                    if (contentType) {
                        recent[i].mimeType = contentType;
                        // זיהוי חכם יותר של סוג המדיה לפי הפורמט שחזר מהשרת
                        if (contentType.includes('video')) recent[i].type = 'וידאו';
                        else if (contentType.includes('audio')) recent[i].type = 'שמע';
                        else if (contentType.includes('image')) recent[i].type = 'תמונה';
                    }
                    updated = true;
                    break;
                }
            }

            // עדכון הרדאר (דיבאג)
            for (let i = 0; i < logs.length; i++) {
                 if (logs[i].id === details.requestId) {
                     if (contentLength) {
                        let bytes = parseInt(contentLength);
                        if (bytes > 1024 * 1024) logs[i].size = (bytes / (1024 * 1024)).toFixed(2) + ' MB';
                        else if (bytes > 1024) logs[i].size = (bytes / 1024).toFixed(2) + ' KB';
                        else logs[i].size = bytes + ' B';
                    }
                    if (contentType) logs[i].mimeType = contentType;
                    updated = true;
                    break;
                 }
            }

            // שומרים רק אם משהו אכן התעדכן
            if (updated) {
                chrome.storage.local.set({ recentDownloads: recent, debugLogs: logs });
            }
        });
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);